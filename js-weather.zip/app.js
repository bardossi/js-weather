import { initForm } from './forms.js';
import './styles.css';
import 'zizi-card';

document.addEventListener('DOMContentLoaded', () => {
    initForm();
})

